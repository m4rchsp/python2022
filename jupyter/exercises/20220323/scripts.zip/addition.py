i1 = int(input("Entrez i1 :"))
i2 = int(input("Entrez i2 :"))
print("i1+i2 = ", i1+i2)
